//
//  Model.swift
//  iGP Sensors Readings
//
//  Created by Shimaa Hassan on 7/2/19.
//  Copyright © 2019 Shimaa Hassan. All rights reserved.
//

import Foundation

struct GPS {
    var lat: Double
    var long: Double
}

struct Compass {
    var head: Double
    var x: Double
    var y: Double
    var z: Double
}
